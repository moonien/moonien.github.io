/* INSTALLING CAPPUCCICONS FONT */
As you may or may not know, the site known as Cappuccicons went down, unavailable for the time being. For those who use the .js file, you'll need to remove it from your wrappers, and instead do the following:

1. Install the font by copying and pasting this just below your other fonts at the top of the stylesheet, before anything else (except the credit if you have one at the top):
	
	@import url('https://files.jcink.net/uploads2/mcodes/css/cuppaccicons.css');

2. For those of you who have it installed like this:

	@import url('//icons.cappuccicons.com/cpf.css');

   Replace the URL with this one:

	https://files.jcink.net/uploads2/mcodes/css/cuppaccicons.css

3. Open the HTML file in the folder titled Cappuccicons, called capp.html, to see all the available icons to use, and how to install them.

4. If you want to install the files yourself in your own Jcink forum, you will need to upload the assets folder content to your file manager, as well as the file titled cuppaccicons.css, then change the path of the font files in the cuppaccicons.css file, then reupload and change the URL in the stylesheet to your own.





If any help is required, please don't hesitate to contact me via Discord at majorcodes#6640, majorcodes2021@gmail.com, or through Tumblr at https://majorcodes.tumblr.com/ask

Thanks for using!